package studentRegistration;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.PersonalDetailsBean;

public class StepDef {
	
	private WebDriver driver;
	private PersonalDetailsBean personalDetailsBean;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver","D:\\Khishore\\Spring 5\\selenium\\chromedriver.exe");
		
		driver=new ChromeDriver();
		personalDetailsBean=new PersonalDetailsBean(driver);
	}
	
	@Given("^valid personal details$")
	public void valid_personal_details() throws Throwable {
	  driver.get("http://localhost:8081/StudentRegistration/finishPayment");
	  personalDetailsBean.studentform("Khishore", "Kumar", "nanganallur", "Mumbai", "TamilNadu", "female", "B.E", "9790854992");
	}

	@When("^valid payment details are submitted$")
	public void valid_payment_details_are_submitted() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert,"Personal Details Successfully Entered!");
		driver.switchTo().alert().accept();
	}

	@Then("^payment successful$")
	public void payment_successful() throws Throwable {
	   
	}
	
}
