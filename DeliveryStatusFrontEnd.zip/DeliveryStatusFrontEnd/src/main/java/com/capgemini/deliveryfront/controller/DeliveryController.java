package com.capgemini.deliveryfront.controller;

import java.util.HashMap;
import javax.validation.Valid;
import com.capgemini.deliveryfront.model.Order;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;



@Controller
public class DeliveryController {
	
	Order order;
	
	@RequestMapping("/home")
	public String getDeliveryPage(ModelMap map) {
		if(order==null) {
			map.put("order", null);
		}
		else{
			map.put("order", order);
		}
		return "DeliveryStatus";
	}
	
	@RequestMapping("/getOrderDetails")
	public String getOrder(@RequestParam("idvalue") String id,ModelMap map) {

		if((id.isEmpty())||(id==null)) {
			order=null;
			return "redirect:/home";
		}
		else { 
			Integer orderId = Integer.parseInt(id);
			final String uri="http://localhost:8083/deliverystatus/api/v2/order/{orderId}";
			RestTemplate restTemplate=new RestTemplate();
					
			java.util.Map<String, Object> params=new HashMap<>();
			params.put("orderId", orderId);
			order= restTemplate.getForObject(uri, Order.class,params);
			
			System.out.println("ORDER====="+order);
			map.put("order",order);
			
			return "DeliveryStatus";
		}
	}
	
	@RequestMapping("/updateOrderDetails")
	public String updateOrder(@Valid @ModelAttribute("order")Order o1,ModelMap map,BindingResult result) {

		if(!result.hasErrors())	{
			final String uri="http://localhost:8083/deliverystatus/api/v2/order/";
			RestTemplate restTemplate=new RestTemplate();
			if(o1.getDeliveryStatus().equals("Delivered"))
			{
				//o1.setDeliveryDate(new Date());
			}
					restTemplate.postForEntity(uri,o1,Order.class);
			order=o1;					
		}
		return "redirect:/home";
	}
	
	/*
	
	//@RequestMapping(value="/savePilot",method=RequestMethod.POST)
	@PostMapping("/savePilot")
	public String showPilotDetails(
			@Valid @ModelAttribute("pilot") Pilot pilot,
			BindingResult result) {
		if(!result.hasErrors()) {
			
			final String uri="http://localhost:8081/PilotRestApp/api/v1/pilots";
			RestTemplate restTemplate=new RestTemplate();
			
		//	ResponseEntity<Pilot> pilot1=
					restTemplate.postForEntity(uri,pilot,Pilot.class);
		
		}
		
		return "redirect:pilotForm";
	}
	
	
	@GetMapping("/delete/{pilotId}")
	public String deletePilot(@PathVariable("pilotId") Integer pilotId) {
		//pilotService.delete(pilotId);
		
		final String uri="http://localhost:8081/PilotRestApp/api/v1/pilots/{pilotId}";
		RestTemplate restTemplate=new RestTemplate();
		
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("pilotId", pilotId);
		//params.put("pilotName", "tom");
		
		restTemplate.delete(uri,params);
		
		return "redirect:/pilotForm";
	}*/
		
}







