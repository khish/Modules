package com.capgemini.deliveryfront.model;

public class Order{
	private int orderId;
	private String deliveryStatus;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public Order() {
		super();
	}
	public Order(int orderId, String deliveryStatus) {
		super();
		this.orderId = orderId;
		this.deliveryStatus = deliveryStatus;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", deliveryStatus=" + deliveryStatus + "]";
	}
	
}
