package com.capgemini.delivery.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="caporder")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Order{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderId;
	private String deliveryStatus;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public Order() {
		super();
	}
	public Order(int orderId, String deliveryStatus) {
		super();
		this.orderId = orderId;
		this.deliveryStatus = deliveryStatus;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", deliveryStatus=" + deliveryStatus + "]";
	}
	
}
