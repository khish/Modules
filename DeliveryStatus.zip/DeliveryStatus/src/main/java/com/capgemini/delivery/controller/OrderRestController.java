package com.capgemini.delivery.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.delivery.model.Order;
import com.capgemini.delivery.service.OrderService;

@RestController
@RequestMapping("/api/v2")
public class OrderRestController {
	
		@Autowired
		private OrderService orderService;
		
		@GetMapping("/order")
		public ResponseEntity<List<Order>> getAll(){
			List<Order> order= orderService.getAll();
			if(order.isEmpty()||order==null)
				return new ResponseEntity
						("Sorry! Order details not available!",HttpStatus.NOT_FOUND);
			return new ResponseEntity<List<Order>>(order,HttpStatus.OK);
		}
		
		@PostMapping("/order")
		public ResponseEntity<Order> create(@RequestBody Order order){
			orderService.save(order);
			
			return new ResponseEntity<Order>(order,HttpStatus.OK);
		}
		
		@GetMapping("/order/{orderId}")
		public ResponseEntity<Order> getOne(@PathVariable("orderId")Integer fid){
			Order order= orderService.getOne(fid);
			if(order==null)
				return new ResponseEntity
						("Sorry! Order detail not available!",HttpStatus.NOT_FOUND);
			return new ResponseEntity<Order>(order,HttpStatus.OK);
		}
		
		@PutMapping("/order")
		public ResponseEntity<Order> update(@RequestBody Order order){
			orderService.save(order);
			if(order.getDeliveryStatus().equals("Undelivered")) {
				
			}
			else if(order.getDeliveryStatus().equals("Delivered"))
			{
				//order.setDeliveryDate(new Date());
			}
			
			return new ResponseEntity<Order>(order,HttpStatus.OK);
		}
		
		@PostMapping("/order/{orderId}")
		public ResponseEntity<Order> deleteOne(@PathVariable("orderId")Integer fid){
			Order order= orderService.getOne(fid);
			if(order==null)
				return new ResponseEntity
						("Sorry! Order detail not available!",HttpStatus.NOT_FOUND);
			else
				orderService.delete(fid);
			return new ResponseEntity<Order>(order,HttpStatus.OK);
		}
}

