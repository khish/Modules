package org.cap.pilot.rest.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Pilot {
	@Id
	@GeneratedValue
	@Column(name="pilot_id")
	private int pilot_id;
	@NotEmpty(message="*please enter firstName.")
	private String first_name;
	private String last_name;
	
	@NotNull(message="* Please enter Date Of Birth.")
	@Past(message="* Please enter past date.")
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date date_of_birth;
	
	@Future(message="* Please nter future date.")
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date date_of_join;
	private Boolean is_certified;
	
	@Range(min=10000,max=200000,message="*Salary should be between 10000 and 2laks.")
	private double salary;
	
	public Pilot() {
		
	}
	

	public Pilot(int pilotId, String firstName, String lastName, Date dateOfBirth, Date dateOfJoin, Boolean isCertified,
			double salary) {
		super();
		this.pilot_id = pilotId;
		this.first_name = firstName;
		this.last_name = lastName;
		this.date_of_birth = dateOfBirth;
		this.date_of_join = dateOfJoin;
		this.is_certified = isCertified;
		this.salary = salary;
	}


	public Date getDateOfBirth() {
		return date_of_birth;
	}


	public void setDateOfBirth(Date dateOfBirth) {
		this.date_of_birth = dateOfBirth;
	}


	public int getPilotId() {
		return pilot_id;
	}
	public void setPilotId(int pilotId) {
		this.pilot_id = pilotId;
	}
	public String getFirstName() {
		return first_name;
	}
	public void setFirstName(String firstName) {
		this.first_name = firstName;
	}
	public String getLastName() {
		return last_name;
	}
	public void setLastName(String lastName) {
		this.last_name = lastName;
	}
	
	public Date getDateOfJoin() {
		return date_of_join;
	}


	public void setDateOfJoin(Date dateOfJoin) {
		this.date_of_join = dateOfJoin;
	}


	public Boolean getIsCertified() {
		return is_certified;
	}

	public void setIsCertified(Boolean isCertified) {
		this.is_certified = isCertified;
	}

	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilot_id + ", firstName=" + first_name + ", lastName=" + last_name + ", dateOfBirth="
				+ date_of_birth + ", dateOfJoin=" + date_of_join + ", isCertified=" + is_certified + ", salary=" + salary
				+ "]";
	}
	
	
	

}
