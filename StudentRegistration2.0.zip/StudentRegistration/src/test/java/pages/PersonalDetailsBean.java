package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PersonalDetailsBean {

	@FindBy(name="firstName")
	private WebElement firstName;
	
	@FindBy(name="lastName")
	private WebElement lastName;
	
	@FindBy(name="address")
	private WebElement address;
	
	@FindBy(name="city")
	private WebElement city;
	
	@FindBy(name="state")
	private WebElement state;
	
	@FindBy(name="gender")
	private List<WebElement> gender;
	
	@FindBy(name="course")
	private WebElement course;
	
	@FindBy(name="mobileNo")
	private WebElement mobileNo;
	
	@FindBy(id="next")
	private WebElement submit;
	
	WebDriver driver;
	
	public PersonalDetailsBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setfirstName(String fname) {
		firstName.sendKeys(fname);
	}
	
	public void setlastName(String lname) {
		lastName.sendKeys(lname);
	}	
	
	public void setaddress(String add) {
		address.sendKeys(add);
	}
	
	public void setcity(String cit) {
		city.sendKeys(cit);
	}
	
	public void setstate(String stat) {
		state.sendKeys(stat);
	}
	
	public void setgender(String gend) {
		if(gend.equals("female"))
			gender.get(1).click();
		else
			gender.get(0).click();
	}
	
	public void setcourse(String cour) {
		course.sendKeys(cour);
	}
	
	public void setmobileNo(String mobile) {
		mobileNo.sendKeys(mobile);
	}
	
	public void setSubmit() {
		submit.click();
	}
	
	public void studentform(String fname,String lname,String address,String city,String state,String gender,String course,String mobile) {
		this.setfirstName(fname);
		this.setlastName(lname);
		this.setaddress(address);
		this.setcity(city);
		this.setstate(state);
		this.setgender(gender);
		this.setcourse(course);
		this.setmobileNo(mobile);
		this.setSubmit();
	}
}
