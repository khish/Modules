package com.cap.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cap.model.Feedback;

@Repository("feedbackDao")
public interface FeedbackDao extends JpaRepository<Feedback,Integer> {

	
}
