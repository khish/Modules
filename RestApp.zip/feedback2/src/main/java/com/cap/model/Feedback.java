package com.cap.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Feedback implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private int feedbackId;
	private int productId;
	private int customerId;
	private int merchantId;
	private String comments;
	private String status;
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public int getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Feedback [productId=" + productId + ", customerId=" + customerId + ", merchantId=" + merchantId
				+ ", feedbackId=" + feedbackId + ", comments=" + comments + ", status=" + status + "]";
	}
	public Feedback(int productId, int customerId, int merchantId, int feedbackId, String comments, String status) {
	//	super();
		this.productId = productId;
		this.customerId = customerId;
		this.merchantId = merchantId;
		this.feedbackId = feedbackId;
		this.comments = comments;
		this.status = status;
	}
	public Feedback() {
		//super();
		
	}
	

}
