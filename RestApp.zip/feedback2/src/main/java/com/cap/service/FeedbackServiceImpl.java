package com.cap.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cap.dao.FeedbackDao;
import com.cap.model.Feedback;
@Service("feedbackService")
@Transactional
public class FeedbackServiceImpl implements FeedbackService{

	@Autowired
	private FeedbackDao feedbackdao;


	@Override
	public void save(Feedback feedback) {
		feedbackdao.save(feedback);
		
	}


	@Override
	public List<Feedback> getAll() {
		return feedbackdao.findAll();
	
	}


	@Override
	public  Feedback getOne(Integer feedbackId) {
		// TODO Auto-generated method stub
		return feedbackdao.getOne(feedbackId);
		 
	}


	
	
}
