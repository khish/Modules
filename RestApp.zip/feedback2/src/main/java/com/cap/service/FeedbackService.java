package com.cap.service;

import java.util.List;



import com.cap.model.Feedback;



public interface FeedbackService {
	public void save(Feedback feedback);
	public List<Feedback> getAll();
	public Feedback getOne(Integer feedbackId);
	
}
