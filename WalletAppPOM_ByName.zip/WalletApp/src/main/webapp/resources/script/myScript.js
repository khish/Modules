/*
function showYearDiv(){
	if(document.getElementById('rd').checked ||
			document.getElementById('fd').checked)
		document.getElementById('yearsDiv').style.display='block';
	else
		document.getElementById('yearsDiv').style.display='none';
}


window.onload= function(){
	document.getElementById('yearsDiv').style.display='none';
}

function validateForm(){
	var uname=myform.customerId.value;
	var upwd=myform.customerPwd.value;
	
	var flag=false;
	if(uname==""||uname==null){
		document.getElementById('userErrMsg').innerHTML=" * Please enter userName.";
	}
	else if(upwd=="" || upwd==null)
		{
		flag=false;
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML=" * Please enter password.";
		}
	else{
		flag=true;
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML="";
	}	
	return flag;
}

function validateCreation(){
	var balance=createForm.obalance.value;
	var flag=false;
	if((balance==""||balance==null)||(balance<1)){
		flag=true;
		document.getElementById('balanceerror').innerHTML="*Minimum balance required.";
	}
	return flag;
}*/

function showYearDiv(){
	if(document.getElementById('rd').checked ||
			document.getElementById('fd').checked)
		document.getElementById('yearsDiv').style.display='block';
	else
		document.getElementById('yearsDiv').style.display='none';
}


window.onload= function(){
	document.getElementById('yearsDiv').style.display='none';
}


function val()
{   
	
	var flag=false;
	if(document.getElementById('savings').checked){
	
		var v=createForm.openingBalance.value;
		
		
		if(v<1000)
		document.getElementById('accErr').innerHTML="Minimum amount should be 1000";
		else
			flag=true;
	}
	else if(document.getElementById('current').checked)
	{	var v=createForm.openingBalance.value;
		if(v<10000)
		document.getElementById('accErr').innerHTML="Minimum amount should be 10000";
		else
			flag=true;
	}
	else if(document.getElementById('rd').checked)
	{
		var v=createForm.openingBalance.value;
		if(v<100)
		document.getElementById('accErr').innerHTML="Minimum amount should be 100";
		else
			flag=true;

	}
	else if(document.getElementById('fd').checked)
	{
		var v=createForm.openingBalance.value;
		if(v<500)
		document.getElementById('accErr').innerHTML="Minimum amount should be 500";
		else
			flag=true;

	}
	else
		{
		document.getElementById('accErr').innerHTML="Please Choose account Type";
		}
	return flag;
}

function validateForm(){
	var uname=myform.customerId.value;
	var upwd=myform.customerPwd.value;
	
	var flag=false;
	if(uname==""||uname==null){
		document.getElementById('userErrMsg').innerHTML=" * Please enter userName.";
	}
	else if(upwd=="" || upwd==null)
		{
		flag=false;
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML=" * Please enter password.";
		}
	else{
		flag=true;
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML="";
	}	
	return flag;
}

function validate2()
{
  var amount=transactor.amount.value;
  var flag=false;
  if(amount<=0)
	  {
	     document.getElementById("errAmount").innerHTML="Amount should be greater than 0";
	     document.getElementById('errTransaction').innerHTML="";
	  }
   return flag;
}
