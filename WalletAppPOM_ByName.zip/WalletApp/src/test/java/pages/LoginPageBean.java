package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPageBean {

	WebDriver driver;
	private By userName=By.name("customerId");
	private By userPass=By.name("customerPwd");
	private By subLogin=By.name("login");
	
	private By pageHeading=By.xpath("//*[@id=\"footer\"]/div[1]/h1");
	
	public LoginPageBean(WebDriver driver) {
		this.driver=driver;
	}
	
	public void setUserName(String usrName) {
		driver.findElement(userName).sendKeys(usrName);
	}
	
	public void setUserPass(String usrPass) {
		driver.findElement(userPass).sendKeys(usrPass);
	}
	
	public void setSubLogin() {
		driver.findElement(subLogin).submit();
	}
	
	public String getPageTitle() {
		return driver.findElement(pageHeading).getText();
	}
	
	public void login_to_nextpage(String uName,String uPass) {
		this.setUserName(uName);
		this.setUserPass(uPass);
		this.setSubLogin();
	}
}
