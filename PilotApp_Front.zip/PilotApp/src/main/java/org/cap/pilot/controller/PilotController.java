package org.cap.pilot.controller;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.cap.pilot.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class PilotController {
	
	
	@RequestMapping("/pilotForm")
	public String getPilotForm(ModelMap map) {
		//List<Pilot> pilots= pilotService.getAll();
		
		final String uri="http://localhost:8083/PilotRestApp/api/v1/pilots";
		RestTemplate restTemplate=new RestTemplate();
		
		Pilot[] pilots= restTemplate.getForObject(uri, Pilot[].class);
		
		
		map.put("pilots",pilots);
		map.put("pilot", new Pilot());
		
		return "pilotForm";
	}
	
	
	
	//@RequestMapping(value="/savePilot",method=RequestMethod.POST)
	@PostMapping("/savePilot")
	public String showPilotDetails(
			@Valid @ModelAttribute("pilot") Pilot pilot,
			BindingResult result) {
		if(!result.hasErrors()) {
			
			final String uri="http://localhost:8083/PilotRestApp/api/v1/pilots";
			RestTemplate restTemplate=new RestTemplate();
			
		//	ResponseEntity<Pilot> pilot1=
					restTemplate.postForEntity(uri,pilot,Pilot.class);
		
		}
		
		return "redirect:pilotForm";
	}
	
	
	@GetMapping("/delete/{pilotId}")
	public String deletePilot(@PathVariable("pilotId") Integer pilotId) {
		//pilotService.delete(pilotId);
		
		final String uri="http://localhost:8083/PilotRestApp/api/v1/pilots/{pilotId}";
		RestTemplate restTemplate=new RestTemplate();
		
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("pilotId", pilotId);
		//params.put("pilotName", "tom");
		
		restTemplate.delete(uri,params);
		
		return "redirect:/pilotForm";
	}
	
	@RequestMapping("/edit/{pilotId}")
	public String editPilot(ModelMap map) {

		final String uri="http://localhost:8083/PilotRestApp/api/v1/pilots";
		RestTemplate restTemplate=new RestTemplate();
		Pilot[] pilots= restTemplate.getForObject(uri, Pilot[].class);
		
		RestTemplate restTemplate1=new RestTemplate();
		final String urii="http://localhost:8083/PilotRestApp/api/v1/pilots/{pilotId}";
		Pilot pilots1= restTemplate1.getForObject(urii, Pilot.class);
		
		System.out.println(pilots1);
		
		map.put("pilots",pilots);
		map.put("pilot", pilots1);
				
		return "redirect:/pilotForm";
	}
	
	
	
	
	
}







