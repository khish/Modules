package org.cap.service;

import java.util.List;

import org.cap.model.Pilot;


public interface IPilotService {
//	public  void savePilot(Pilot pilot);
	 public List<Pilot> getAll();
	public void delete(Integer pilotId);
	public void edit(Pilot pilot1);
	public Pilot findPilot(Integer pilotId);
	
}
