package org.cap.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("pilotDbDao")
@Transactional
public class PilotDaoDbImpl implements IPilotDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<Pilot> getAllPilots() {
		List<Pilot> pilots = entityManager.createQuery("from Pilot").getResultList();
		return pilots;
	}

	@Override
	public Pilot findPilot(int pilotId) {
		Pilot pilot = entityManager.find(Pilot.class, pilotId);
		return pilot;
	}

	@Override
	public List<Pilot> deletePilot(int pilotId) {
		Pilot pilot = entityManager.find(Pilot.class, pilotId);
		entityManager.remove(pilot);
		return getAllPilots();
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		entityManager.persist(pilot);
		return getAllPilots();
	}

	@Override
	public List<Pilot> updatePilot(Pilot pilot) {
		if(findPilot(pilot.getPilotId())!=null) {
			entityManager.merge(pilot);
			return getAllPilots();
		}
		return null;
	}

}
