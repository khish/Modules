package org.cap.service;

import java.util.List;

import org.cap.model.Pilot;

public interface IPilotService {

	public List<Pilot> getAllPilots();
	public Pilot findPilot(int pilotId);
	public List<Pilot> deletePilot(int pilotId);
	public List<Pilot> createPilot(Pilot pilot);
	public List<Pilot> updatePilot(Pilot pilot);
	
}
