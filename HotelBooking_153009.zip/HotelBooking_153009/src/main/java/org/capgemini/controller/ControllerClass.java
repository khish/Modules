package org.capgemini.controller;

import java.util.List;

import org.capgemini.model.HotelDetails;
import org.capgemini.service.IHotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ControllerClass {

	@Autowired
	private IHotelService hotelService;
	private String hotelName;
	
	@RequestMapping("/")
	public String firstPage(ModelMap map) {
		List<HotelDetails> hotels = hotelService.getAllHotels();
		map.put("hotels",hotels);
		return "HotelDetails";
	}
	
	@RequestMapping("/book/{name}")
	public String secondpage(@PathVariable("name")String name) {
		hotelName=name;
		return "HotelBooking";
	}

	@RequestMapping("/book/Booking/room")
	public String thirdpage(ModelMap map) {
		map.put("hotelname", hotelName);
		return "BookingConfirmation";
	}
	
}
