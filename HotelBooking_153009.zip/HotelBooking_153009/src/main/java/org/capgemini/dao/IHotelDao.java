package org.capgemini.dao;

import java.util.List;

import org.capgemini.model.HotelDetails;

public interface IHotelDao {

	public List<HotelDetails> getAllHotels();
	
}
