package org.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.capgemini.model.HotelDetails;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("hotelDao")
@Transactional
public class HotelDaoImpl implements IHotelDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<HotelDetails> getAllHotels() {
		List<HotelDetails> hotels = entityManager.createQuery("from HotelDetails").getResultList(); 
		return hotels;
	}

}
