package org.capgemini.service;

import java.util.List;

import org.capgemini.dao.IHotelDao;
import org.capgemini.model.HotelDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("hotelService")
public class HotelServiceImpl implements IHotelService{

	@Autowired
	private IHotelDao hotelDao;
	
	@Override
	public List<HotelDetails> getAllHotels() {
		// TODO Auto-generated method stub
		return hotelDao.getAllHotels();
	}

}
