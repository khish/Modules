package org.capgemini.service;

import java.util.List;

import org.capgemini.model.HotelDetails;

public interface IHotelService {

	public List<HotelDetails> getAllHotels();
	
}
